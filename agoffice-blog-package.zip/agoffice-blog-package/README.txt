AGOffice blog package
=====================

1) blog/  (goes on your website)
   Upload the whole "blog" folder to your GitHub site, next to index.html.
   Your blog will then live at yoursite.com/blog/

2) homepage-update/index.html  (one-line change to your home page)
   The ONLY difference from your current index.html: the footer "Blog" text is now a link to /blog/.
   Replace your index.html with this file, or make that one edit yourself.

3) post-composer.html  (private, do NOT upload)
   Keep this on your computer. To publish a post:
     a. Download the current blog/blog-data.js from GitHub.
     b. Open post-composer.html in your browser and click "Open blog-data.js...", then pick that file.
     c. Write or edit a post, then go to the Export tab and click "Download everything (.zip)".
     d. Unzip it. In GitHub, open the blog folder > Add file > Upload files, drag in everything from the unzipped folder, and commit.
   Uploading a file with the same name replaces it automatically. Nothing needs to be deleted.
